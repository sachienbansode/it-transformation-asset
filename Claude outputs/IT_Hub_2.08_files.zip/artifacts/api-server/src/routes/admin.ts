import { clearUploadPolicyCache } from "../lib/upload-policy";
import { Router } from "express";
import { eq, and, lt, sql } from "drizzle-orm";
import { db, usersTable, settingsTable } from "@workspace/db";
import { pool } from "@workspace/db";
import { z } from "zod";
import { requireAdmin } from "./auth";
import bcrypt from "bcryptjs";
import { forceSeedProductionDatabase } from "../seed-production";
import { logAudit, getPerformedBy } from "./audit-logs";
import { fmtCell } from "../lib/dates";

const router = Router();

// ─── CSV EXPORT of users and master tables (Admin) ──────────
// Fixed list of tables and columns (no SQL from the request). Secrets are never exported.
const EXPORTS: Record<string, { file: string; sql: ReturnType<typeof sql> }> = {
  users: { file: "users", sql: sql`SELECT u.id, u.employee_code, u.name, u.email, u.mobile, u.user_type, CASE WHEN u.role = 'admin' THEN 'Super Admin' ELSE u.role END AS base_role, coalesce((SELECT m.label FROM masters m WHERE m.category = 'department' AND (lower(m.key) = lower(u.department) OR lower(m.label) = lower(u.department)) ORDER BY m.is_active DESC LIMIT 1), u.department) AS department, u.designation, u.is_active, u.status, CASE WHEN u.auth_method = 'm365' THEN 'Microsoft 365' ELSE 'IT Hub password' END AS sign_in_method, u.mfa_enabled, CASE WHEN u.mfa_enabled THEN u.mfa_method END AS mfa_method, u.must_change_password, u.password_changed_at, u.last_login_at, u.created_at,
    (SELECT string_agg(r.name, '; ') FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = u.id) AS roles FROM users u ORDER BY u.name` },
  masters: { file: "master_data", sql: sql`SELECT id, category, key, label, color, sort_order, is_active FROM masters ORDER BY category, sort_order, label` },
  business_units: { file: "business_units", sql: sql`SELECT * FROM business_units ORDER BY 1` },
  roles: { file: "roles", sql: sql`SELECT * FROM roles ORDER BY 1` },
  role_permissions: { file: "role_permissions", sql: sql`SELECT rp.*, r.name AS role_name FROM role_permissions rp LEFT JOIN roles r ON r.id = rp.role_id ORDER BY rp.role_id` },
  user_roles: { file: "user_roles", sql: sql`SELECT ur.*, u.email, r.name AS role_name FROM user_roles ur LEFT JOIN users u ON u.id = ur.user_id LEFT JOIN roles r ON r.id = ur.role_id ORDER BY u.email` },
  asset_categories: { file: "asset_categories", sql: sql`SELECT * FROM asset_categories ORDER BY 1` },
  kpi_categories: { file: "kpi_categories", sql: sql`SELECT * FROM kpi_categories ORDER BY 1` },
  compliance_statuses: { file: "compliance_checkpoint_statuses", sql: sql`SELECT name, stage, grp AS dashboard_bucket, color, sort_order, is_active, is_system, description FROM cmp_statuses ORDER BY sort_order` },
  compliance_companies: { file: "compliance_companies", sql: sql`SELECT * FROM cmp_companies ORDER BY 1` },
};
const SECRET = /password|secret|token|hash|azure_id|central_sub/i;
const csvCell = (raw: unknown) => {
  const v = fmtCell(raw);
  if (v === null || v === undefined) return "";
  let t = v instanceof Date ? v.toISOString() : typeof v === "object" ? JSON.stringify(v) : String(v);
  if (/^[=+\-@\t\r]/.test(t)) t = "'" + t; // no formula injection when opened in Excel
  return /[",\n\r]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t;
};
router.get("/admin/export", requireAdmin, (_req, res): void => { res.json(Object.keys(EXPORTS)); });
router.get("/admin/export/:name", requireAdmin, async (req, res): Promise<void> => {
  const e = EXPORTS[String(req.params.name)];
  if (!e) { res.status(404).json({ error: "Unknown export" }); return; }
  try {
    const r: any = await db.execute(e.sql); const rows: any[] = r.rows ?? r;
    const cols = (rows[0] ? Object.keys(rows[0]) : (r.fields || []).map((f: any) => f.name)).filter((c: string) => !SECRET.test(c));
    const body = "\uFEFF" + [cols.join(","), ...rows.map(x => cols.map((c: string) => csvCell(x[c])).join(","))].join("\r\n");
    const stamp = new Date(Date.now() + 330 * 60_000).toISOString().slice(0, 10);
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${e.file}_${stamp}.csv"`);
    await logAudit({ entityType: "admin_export", action: "export", performedBy: await getPerformedBy((req.session as any)?.userId).catch(() => "Admin"), summary: `${e.file}.csv exported (${rows.length} rows)` }).catch(() => {});
    res.send(body);
  } catch (err: any) { res.status(500).json({ error: err?.message || "Export failed" }); }
});

// ─── SETTINGS ────────────────────────────────────────────────

const SECRET_MASK = "••••••••";
router.get("/admin/settings", requireAdmin, async (_req, res): Promise<void> => {
  const rows = await db.select().from(settingsTable);
  const settings: Record<string, unknown> = {};
  for (const row of rows) settings[row.key] = row.value;
  // r95: secrets never go back to the browser — only whether one is saved
  if (settings["sso.clientSecret"]) settings["sso.clientSecret"] = SECRET_MASK;
  res.json(settings);
});

router.put("/admin/settings", requireAdmin, async (req, res): Promise<void> => {
  const body = z.record(z.string(), z.unknown()).safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: "Invalid body" }); return; }
  for (const [key, value] of Object.entries(body.data)) {
    if (key.startsWith("tenant.")) continue;   // client-instance facts are set by the server scripts only
    if (key === "sso.clientSecret") {          // r95: stored encrypted; the mask (or empty) means "keep the saved one"
      const v = String(value ?? "").trim();
      if (!v || v === SECRET_MASK) continue;
      const { sealText } = await import("../lib/secure-text");
      await db.insert(settingsTable).values({ key, value: sealText(v) as any }).onConflictDoUpdate({ target: settingsTable.key, set: { value: sealText(v) as any } });
      continue;
    }
    await db
      .insert(settingsTable)
      .values({ key, value })
      .onConflictDoUpdate({ target: settingsTable.key, set: { value } });
  }
  clearUploadPolicyCache();
  res.json({ ok: true });
});

// r95: test Microsoft SSO settings from the server (tenant, app ID and client secret) without signing anyone in
router.post("/admin/sso/test", requireAdmin, async (req, res): Promise<void> => {
  const b = req.body || {};
  const get = async (k: string) => { const [r] = await db.select({ value: settingsTable.value }).from(settingsTable).where(eq(settingsTable.key, k)); return r?.value as any; };
  const tenantId = String(b.tenantId ?? await get("sso.tenantId") ?? "").trim();
  const clientId = String(b.clientId ?? await get("sso.clientId") ?? "").trim();
  let secret = String(b.clientSecret ?? "").trim();
  const { openText } = await import("../lib/secure-text");
  if (!secret || secret === SECRET_MASK) secret = openText(String(await get("sso.clientSecret") || ""));
  const base = String(process.env.APP_URL || `${req.protocol}://${req.get("host")}`).replace(/\/$/, "");
  const redirectUri = String(b.redirectUri || await get("sso.redirectUri") || "").trim() || `${base}/api/auth/sso/callback`;
  const steps: { step: string; ok: boolean; detail: string }[] = [];
  const add = (step: string, ok: boolean, detail: string) => { steps.push({ step, ok, detail }); return ok; };
  const guid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  try {
    if (!add("Values entered", !!tenantId && !!clientId && !!secret, [!tenantId && "Tenant ID", !clientId && "Client ID", !secret && "Client secret"].filter(Boolean).join(", ") ? `Missing: ${[!tenantId && "Tenant ID", !clientId && "Client ID", !secret && "Client secret"].filter(Boolean).join(", ")}` : "Tenant ID, Client ID and Client secret are filled in")) return void res.json({ ok: false, steps, redirectUri });
    add("Client ID format", guid.test(clientId), guid.test(clientId) ? "Looks like an Application (client) ID" : "Should look like xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx (Overview › Application (client) ID)");
    if (guid.test(secret)) add("Client secret", false, "This looks like the Secret ID. Use the secret VALUE (shown only once when the secret is created).");
    const meta = await fetch(`https://login.microsoftonline.com/${encodeURIComponent(tenantId)}/v2.0/.well-known/openid-configuration`, { signal: AbortSignal.timeout(10_000) });
    const mj: any = await meta.json().catch(() => ({}));
    if (!add("Tenant found", meta.ok && !!mj.issuer, meta.ok ? `Microsoft Entra tenant reachable (${String(mj.issuer || "").split("/")[3] || tenantId})` : `Tenant not found — check the Directory (tenant) ID (${mj.error_description?.split("\r")[0] || meta.status})`)) return void res.json({ ok: false, steps, redirectUri });
    const tr = await fetch(`https://login.microsoftonline.com/${encodeURIComponent(tenantId)}/oauth2/v2.0/token`, {
      method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, signal: AbortSignal.timeout(10_000),
      body: new URLSearchParams({ client_id: clientId, client_secret: secret, grant_type: "client_credentials", scope: "https://graph.microsoft.com/.default" }) });
    const tj: any = await tr.json().catch(() => ({}));
    const code = String(tj.error_description || "").match(/AADSTS(\d+)/)?.[1];
    const why: Record<string, string> = { "7000215": "Client secret is wrong — use the secret VALUE, not the Secret ID", "7000222": "Client secret has expired — create a new one", "700016": "App (client) ID not found in this tenant", "90002": "Tenant not found", "700023": "App is not allowed for this tenant" };
    add("App ID and client secret accepted by Microsoft", tr.ok, tr.ok ? "Microsoft issued a token for this app — ID and secret are correct" : (code && why[code]) || String(tj.error_description || tj.error || tr.status).split("\r")[0].slice(0, 300));
    add("Redirect URI to register (Web)", /^https:\/\//.test(redirectUri) || /localhost|127\.0\.0\.1/.test(redirectUri), redirectUri + (/^https:\/\//.test(redirectUri) ? "" : " — Microsoft needs HTTPS"));
    res.json({ ok: steps.every(s => s.ok), steps, redirectUri });
  } catch (e: any) {
    add("Reach Microsoft", false, `The server could not reach login.microsoftonline.com (${e?.message || e}) — check outbound HTTPS / proxy on this server`);
    res.json({ ok: false, steps, redirectUri });
  }
});

// ─── USERS ────────────────────────────────────────────────────

function autoDormantDate() {
  return new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
}

router.get("/admin/users", requireAdmin, async (_req, res): Promise<void> => {
  // Auto-mark users dormant if inactive for 30+ days
  await db
    .update(usersTable)
    .set({ status: "dormant" })
    .where(
      and(
        eq(usersTable.status, "active"),
        lt(usersTable.lastLoginAt, autoDormantDate())
      )
    );

  const users = await db
    .select({
      id: usersTable.id,
      email: usersTable.email,
      name: usersTable.name,
      userType: usersTable.userType,
      role: usersTable.role,
      department: usersTable.department, authMethod: usersTable.authMethod,
      designation: usersTable.designation,
      reportingManagerId: usersTable.reportingManagerId,
      employeeCode: usersTable.employeeCode,
      mobile: usersTable.mobile,
      mfaEnabled: usersTable.mfaEnabled,
      mfaMethod: usersTable.mfaMethod,
      isActive: usersTable.isActive,
      status: usersTable.status,
      lastLoginAt: usersTable.lastLoginAt,
      createdAt: usersTable.createdAt,
    })
    .from(usersTable)
    .orderBy(usersTable.createdAt);
  const nameOf = new Map(users.map(u => [u.id, u.name]));
  // 2.08 (ITH-188): access roles per user for the list
  const rr: any = await db.execute(sql`SELECT ur.user_id, r.name FROM user_roles ur JOIN roles r ON r.id = ur.role_id ORDER BY r.name`);
  const rolesOf = new Map<number, string[]>(); for (const x of (rr.rows ?? rr) as any[]) rolesOf.set(Number(x.user_id), [...(rolesOf.get(Number(x.user_id)) || []), x.name]);
  res.json(users.map(u => ({ ...u, accessRoles: rolesOf.get(u.id) || [], reportingManager: u.reportingManagerId ? nameOf.get(u.reportingManagerId) || null : null })));
});

/** Employee codes are unique (case-insensitive) — they map people to assets. Returns the clashing user, if any. */
async function employeeCodeClash(code: string, exceptId: number | null) {
  const [u] = await db.select({ id: usersTable.id, name: usersTable.name, email: usersTable.email }).from(usersTable)
    .where(sql`lower(${usersTable.employeeCode}) = lower(${code})${exceptId ? sql` AND ${usersTable.id} <> ${exceptId}` : sql``}`);
  return u ? `${u.name} (${u.email})` : null;
}

/** ITH-109 — reporting manager: an active user, not the person themselves, and no loop (A → B → A). */
async function managerProblem(userId: number | null, managerId: number | null | undefined) {
  if (!managerId) return null;
  const [m] = await db.select({ id: usersTable.id, isActive: usersTable.isActive, name: usersTable.name }).from(usersTable).where(eq(usersTable.id, managerId));
  if (!m) return "The reporting manager was not found";
  if (!m.isActive) return `${m.name} is not an active user`;
  if (userId && managerId === userId) return "A person cannot be their own reporting manager";
  if (userId) { let cur: number | null = managerId; for (let i = 0; cur && i < 20; i++) { const [r] = await db.select({ mgr: usersTable.reportingManagerId }).from(usersTable).where(eq(usersTable.id, cur)); cur = r?.mgr ?? null; if (cur === userId) return `${m.name} already reports (directly or indirectly) to this person`; } }
  return null;
}

router.post("/admin/users", requireAdmin, async (req, res): Promise<void> => {
  const body = z.object({
    email: z.string().email(),
    name: z.string().min(1),
    password: z.string().min(8).optional(),
    userType: z.enum(["internal", "external"]).default("internal"),
    role: z.enum(["admin", "user", "cxo", "kpi_employee", "hr"]).default("user"),
    department: z.string().min(1),
    designation: z.string().min(1),
    employeeCode: z.string().min(1),
    mobile: z.string().optional(),
    status: z.enum(["active", "inactive", "dormant"]).default("active"),
    isActive: z.boolean().default(true),
    reportingManagerId: z.number().int().positive().nullable().optional(),
    authMethod: z.enum(["password", "m365"]).optional(),
  }).safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: body.error.message }); return; }
  const { password, ...rest } = body.data;
  rest.email = rest.email.trim().toLowerCase();
  { const { deptLabel } = await import("../lib/dept"); rest.department = (await deptLabel(rest.department)) || rest.department; }   // r98: store the department NAME
  // r98: sign-in method — Microsoft 365 when chosen (or when SSO is on and no password was given), else IT Hub password
  if (!rest.authMethod) { const [sso] = await db.select({ value: settingsTable.value }).from(settingsTable).where(eq(settingsTable.key, "sso.msEnabled")); rest.authMethod = (sso?.value === true && !password) ? "m365" : "password"; }
  if (rest.authMethod === "password" && !password) { res.status(400).json({ error: "Set a temporary password, or choose sign-in with Microsoft 365" }); return; }
  if (password) { const { getPolicy, policyProblems, policyMessage } = await import("../lib/password-policy"); const pr = policyProblems(password, await getPolicy(), rest.email); if (pr.length) { res.status(400).json({ error: `Temporary password: ${policyMessage(pr)}` }); return; } }
  rest.employeeCode = rest.employeeCode.trim();
  const mp = await managerProblem(null, rest.reportingManagerId); if (mp) { res.status(400).json({ error: mp }); return; }
  const clash = await employeeCodeClash(rest.employeeCode, null);
  if (clash) { res.status(400).json({ error: `Employee code ${rest.employeeCode} is already used by ${clash}` }); return; }
  const [emailClash] = await db.select({ id: usersTable.id }).from(usersTable).where(sql`lower(${usersTable.email}) = ${rest.email}`);
  if (emailClash) { res.status(400).json({ error: `A user with email ${rest.email} already exists` }); return; }
  const passwordHash = password ? await bcrypt.hash(password, 12) : null;
  const [user] = await db.insert(usersTable).values({ ...rest, passwordHash, mustChangePassword: !!password }).returning({
    id: usersTable.id, email: usersTable.email, name: usersTable.name,
    userType: usersTable.userType, role: usersTable.role, status: usersTable.status,
    mobile: usersTable.mobile,
  });
  const adminName = await getPerformedBy((req as any).user?.id);
  logAudit({ entityType: "user", entityId: user.id, action: "create", performedBy: adminName, summary: `Created user ${user.email} with role "${user.role}"`, newValues: { email: user.email, role: user.role, status: user.status } }).catch(() => {});
  { const { ensureDefaultRole } = await import("../lib/default-role"); await ensureDefaultRole(user.id).catch(() => {}); }
  res.status(201).json(user);
});

router.patch("/admin/users/:id", requireAdmin, async (req, res): Promise<void> => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const body = z.object({
    name: z.string().optional(),
    email: z.string().email().optional(),
    userType: z.enum(["internal", "external"]).optional(),
    role: z.enum(["admin", "user", "cxo", "kpi_employee", "hr"]).optional(),
    department: z.string().optional(),
    designation: z.string().optional(),
    employeeCode: z.string().optional(),
    mobile: z.string().optional(),
    status: z.enum(["active", "inactive", "dormant"]).optional(),
    isActive: z.boolean().optional(),
    mfaEnabled: z.boolean().optional(),
    password: z.string().min(8).optional(),
    reportingManagerId: z.number().int().positive().nullable().optional(),
    authMethod: z.enum(["password", "m365"]).optional(),
  }).safeParse(req.body);
  if (!body.success) { res.status(400).json({ error: body.error.message }); return; }
  const { password, ...rest } = body.data;
  if (rest.department !== undefined) { const { deptLabel } = await import("../lib/dept"); rest.department = (await deptLabel(rest.department)) || rest.department; }   // r98
  if (password) { const { getPolicy, policyProblems, policyMessage } = await import("../lib/password-policy"); const [u0] = await db.select({ email: usersTable.email }).from(usersTable).where(eq(usersTable.id, id)); const pr = policyProblems(password, await getPolicy(), u0?.email); if (pr.length) { res.status(400).json({ error: `Temporary password: ${policyMessage(pr)}` }); return; } }
  if (rest.authMethod === "password" && !password) {
    const [cur] = await db.select({ h: usersTable.passwordHash }).from(usersTable).where(eq(usersTable.id, id));
    if (!cur?.h) { res.status(400).json({ error: "This person has no IT Hub password yet — set a temporary password to switch them to password sign-in" }); return; }
  }
  if (rest.email !== undefined) {
    rest.email = rest.email.trim().toLowerCase();
    const [clash] = await db.select({ id: usersTable.id }).from(usersTable).where(sql`lower(${usersTable.email}) = ${rest.email} AND ${usersTable.id} <> ${id}`);
    if (clash) { res.status(400).json({ error: `Another user already uses ${rest.email}` }); return; }
  }
  if (rest.reportingManagerId !== undefined) { const mp = await managerProblem(id, rest.reportingManagerId); if (mp) { res.status(400).json({ error: mp }); return; } }
  if (rest.employeeCode !== undefined) {
    rest.employeeCode = rest.employeeCode.trim();
    if (!rest.employeeCode) { res.status(400).json({ error: "Employee code cannot be blank — it links the user to their assets" }); return; }
    const clash = await employeeCodeClash(rest.employeeCode, id);
    if (clash) { res.status(400).json({ error: `Employee code ${rest.employeeCode} is already used by ${clash}` }); return; }
  }
  const update: Record<string, unknown> = { ...rest };
  // Keep isActive in sync with status
  if (rest.status === "active") {
    update.isActive = true;
    // Reset lastLoginAt so auto-dormant doesn't immediately re-trigger on next GET
    update.lastLoginAt = new Date();
  }
  if (rest.status === "inactive" || rest.status === "dormant") update.isActive = false;
  if (password) { update.passwordHash = await bcrypt.hash(password, 12); update.mustChangePassword = true; }   // r94: reset by admin = temporary
  const [oldUser] = await db.select({
    email: usersTable.email, name: usersTable.name, role: usersTable.role, status: usersTable.status,
    department: usersTable.department, designation: usersTable.designation, mobile: usersTable.mobile,
    userType: usersTable.userType, employeeCode: usersTable.employeeCode, mfaEnabled: usersTable.mfaEnabled, reportingManagerId: usersTable.reportingManagerId,
  }).from(usersTable).where(eq(usersTable.id, id));
  const [user] = await db.update(usersTable).set(update).where(eq(usersTable.id, id)).returning({
    id: usersTable.id, email: usersTable.email, name: usersTable.name,
    userType: usersTable.userType, role: usersTable.role, status: usersTable.status,
    department: usersTable.department, designation: usersTable.designation,
    mobile: usersTable.mobile, mfaEnabled: usersTable.mfaEnabled, employeeCode: usersTable.employeeCode, reportingManagerId: usersTable.reportingManagerId,
  });
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  const adminNameU = await getPerformedBy((req as any).user?.id);
  const updatedKeys = Object.keys(body.data).filter(k => k !== "password");
  const oldSnap: Record<string, unknown> = {};
  const newSnap: Record<string, unknown> = {};
  for (const k of updatedKeys) {
    oldSnap[k] = (oldUser as any)?.[k];
    newSnap[k] = (user as any)[k] ?? (rest as any)[k];
  }
  if ("reportingManagerId" in oldSnap) {   // audit names, not ids
    const nm = async (v: any) => v ? (await db.select({ n: usersTable.name }).from(usersTable).where(eq(usersTable.id, Number(v))))[0]?.n || `#${v}` : "none";
    if (oldSnap.reportingManagerId !== newSnap.reportingManagerId) { oldSnap.reportingManagerId = await nm(oldSnap.reportingManagerId); newSnap.reportingManagerId = await nm(newSnap.reportingManagerId); } else { oldSnap.reportingManagerId = newSnap.reportingManagerId; }
  }
  logAudit({ entityType: "user", entityId: user.id, action: "update", performedBy: adminNameU, summary: `Updated user ${user.email}: ${updatedKeys.filter(k => oldSnap[k] !== newSnap[k]).map(k => `${k}: "${oldSnap[k]}" → "${newSnap[k]}"`).join(", ") || updatedKeys.join(", ")}`, oldValues: oldSnap, newValues: newSnap }).catch(() => {});
  { const { ensureDefaultRole } = await import("../lib/default-role"); await ensureDefaultRole(id).catch(() => {}); }
  res.json(user);
});

router.delete("/admin/users/:id", requireAdmin, async (req, res): Promise<void> => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [target] = await db.select({ email: usersTable.email, role: usersTable.role }).from(usersTable).where(eq(usersTable.id, id));
  const [user] = await db.delete(usersTable).where(eq(usersTable.id, id)).returning();
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  const adminNameD = await getPerformedBy((req as any).user?.id);
  logAudit({ entityType: "User", entityId: id, action: "DELETE", performedBy: adminNameD, summary: `User deleted: ${target?.email ?? id} (${target?.role ?? "?"})`, oldValues: target }).catch(() => {});
  res.sendStatus(204);
});

// ─── TEMPORARY: ONE-TIME PRODUCTION DB RESET ─────────────────
router.post("/admin/force-seed", requireAdmin, async (_req, res): Promise<void> => {
  try {
    await forceSeedProductionDatabase();
    res.json({ ok: true, message: "All tables truncated and re-seeded with full dev dataset." });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: "Force seed failed", detail: msg });
  }
});

// Safe endpoint: inserts checklist items for businesses that have none — never wipes data
router.post("/admin/seed-missing-checklist", requireAdmin, async (_req, res): Promise<void> => {
  try {
    const newItems = [
      // IE — Insurance & Education
      [77, 'Policy & Product Management', 'Policy Administration System', 'IE', 'Custom Portal', 'Available', 'High', 'Life & health policy lifecycle management'],
      [78, 'Policy & Product Management', 'Claims Management System', 'IE', 'Finacle Claims', 'Partial', 'High', 'Partial automation; manual adjudication'],
      [79, 'Policy & Product Management', 'Underwriting Engine', 'IE', 'Manual + Excel', 'Legacy', 'High', 'Rules-based engine needed'],
      [80, 'Policy & Product Management', 'Customer Self-Service Portal', 'IE', 'Not Available', 'Not Available', 'High', 'No digital self-service yet'],
      [81, 'Compliance & KYC', 'KYC/AML Platform', 'IE', 'KarvyKYC Pro', 'Available', 'High', 'IRDAI-compliant KYC'],
      [82, 'Compliance & KYC', 'IRDAI Regulatory Reporting', 'IE', 'Manual + Excel', 'Legacy', 'High', 'Manual filing; automation pending'],
      [83, 'Education Platform', 'Learning Management System', 'IE', 'Moodle', 'Available', 'Medium', 'LMS deployed for Ashika Academy'],
      [84, 'Education Platform', 'SEBI NISM Exam Integration', 'IE', 'Partial', 'Partial', 'Medium', 'Exam registration linked; score sync pending'],
      // MF — Mutual Fund
      [85, 'Fund Operations', 'Portfolio Management System', 'MF', 'Advent Geneva', 'Available', 'High', 'Core PMS for fund management'],
      [86, 'Fund Operations', 'NAV Calculation Engine', 'MF', 'Custom + Geneva', 'Available', 'High', 'Daily NAV calculation automated'],
      [87, 'Fund Operations', 'Investor Portal & Reporting', 'MF', 'Custom Portal', 'Partial', 'High', 'Partial features; SOA download missing'],
      [88, 'Fund Operations', 'SIP & STP Processing System', 'MF', 'Finacle', 'Available', 'High', 'SIP automation live; STP partial'],
      [89, 'Compliance & Regulatory', 'SEBI MF Compliance Module', 'MF', 'Manual + Excel', 'Legacy', 'High', 'Manual SEBI filings; automation needed'],
      [90, 'Compliance & Regulatory', 'CKYC / KYC Integration', 'MF', 'KarvyKYC Pro', 'Available', 'High', 'CKYC registry integrated'],
      [91, 'Fund Accounting', 'Fund Accounting System', 'MF', 'Advent Geneva', 'Available', 'High', 'GL and sub-ledger managed via Geneva'],
      [92, 'Fund Accounting', 'Unit Holder Register (UTR)', 'MF', 'Custom', 'Partial', 'Medium', 'Unit holder data partially digitised'],
      // IB — Investment Banking
      [93, 'Deal Management', 'Deal Pipeline & CRM', 'IB', 'Salesforce CRM', 'Partial', 'High', 'CRM active; deal stage automation pending'],
      [94, 'Deal Management', 'Financial Modelling Platform', 'IB', 'Excel + Python', 'Legacy', 'High', 'Manual models; SaaS platform needed'],
      [95, 'Deal Management', 'Virtual Data Room (VDR)', 'IB', 'Not Available', 'Not Available', 'High', 'No secure VDR; using email/SharePoint'],
      [96, 'Due Diligence', 'Due Diligence Management Platform', 'IB', 'Manual + Excel', 'Legacy', 'High', 'No structured DD workflow tool'],
      [97, 'Due Diligence', 'Company Research & Analytics', 'IB', 'Bloomberg Terminal', 'Available', 'High', 'Bloomberg active for market data & comps'],
      [98, 'Regulatory & Compliance', 'SEBI IB Regulatory Filing System', 'IB', 'Manual', 'Legacy', 'High', 'Manual filings to SEBI; portal integration needed'],
      [99, 'Regulatory & Compliance', 'Conflict of Interest Management', 'IB', 'Not Available', 'Not Available', 'Medium', 'No system; policy-only controls'],
      [100, 'Pitch & Reporting', 'Pitch Book Automation Tool', 'IB', 'Not Available', 'Not Available', 'Medium', 'PowerPoint-only; no automation'],
    ] as const;

    const inserted: number[] = [];
    const skipped: number[] = [];
    for (const [id, category, feature, business, currentTool, status, priority, notes] of newItems) {
      const existing = await pool.query('SELECT id FROM checklist_items WHERE id = $1', [id]);
      if (existing.rows.length > 0) { skipped.push(id); continue; }
      await pool.query(
        `INSERT INTO checklist_items (id, category, feature, business, current_app, status, priority, comments)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [id, category, feature, business, currentTool, status, priority, notes]
      );
      inserted.push(id);
    }
    res.json({ ok: true, inserted: inserted.length, skipped: skipped.length, insertedIds: inserted });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: "Seed missing checklist failed", detail: msg });
  }
});

// ─── SAFE ITSM APPROVAL MATRIX SEED (idempotent, no truncate) ───
router.post("/admin/seed-itsm-approval-matrix", requireAdmin, async (_req, res): Promise<void> => {
  const rules = [
    { ticketType: "Incident", condition: "All", approverRole: "Service Desk Manager", approverLevel: "L1", sequence: 1 },
    { ticketType: "Incident", condition: "Priority:Critical,High", approverRole: "IT Manager", approverLevel: "L2", sequence: 2 },
    { ticketType: "Incident", condition: "Severity:S1", approverRole: "CTO / IT Director", approverLevel: "L3", sequence: 3 },
    { ticketType: "Incident", condition: "Severity:S1", approverRole: "CTO", approverLevel: "L4", sequence: 4 },
    { ticketType: "Problem", condition: "All", approverRole: "Problem Manager", approverLevel: "L1", sequence: 1 },
    { ticketType: "Problem", condition: "Priority:Critical,High", approverRole: "IT Manager", approverLevel: "L2", sequence: 2 },
    { ticketType: "Change Request", condition: "All", approverRole: "Change Manager", approverLevel: "L1", sequence: 1 },
    { ticketType: "Change Request", condition: "All", approverRole: "Change Advisory Board (CAB)", approverLevel: "L2", sequence: 2 },
    { ticketType: "Change Request", condition: "Type:Emergency", approverRole: "CTO / IT Director", approverLevel: "L3", sequence: 3 },
    { ticketType: "Service Request", condition: "All", approverRole: "Team Lead / Supervisor", approverLevel: "L1", sequence: 1 },
    { ticketType: "Service Request", condition: "Priority:Critical,High", approverRole: "IT Manager", approverLevel: "L2", sequence: 2 },
  ];
  try {
    const existing = await pool.query("SELECT COUNT(*)::int AS cnt FROM itsm_approval_matrix WHERE is_active = true");
    if (existing.rows[0]?.cnt > 0) {
      res.json({ ok: true, message: `Already seeded — ${existing.rows[0].cnt} active rules exist.`, skipped: true });
      return;
    }
    for (const r of rules) {
      await pool.query(
        `INSERT INTO itsm_approval_matrix (ticket_type, condition, approver_role, approver_level, sequence, is_active)
         VALUES ($1,$2,$3,$4,$5,true) ON CONFLICT DO NOTHING`,
        [r.ticketType, r.condition, r.approverRole, r.approverLevel, r.sequence]
      );
    }
    res.json({ ok: true, message: `Seeded ${rules.length} approval matrix rules.` });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: "Seed failed", detail: msg });
  }
});

// ─── SAFE: Create itsm_attachments table if missing in prod ─────
router.post("/admin/migrate-itsm-attachments", requireAdmin, async (_req, res): Promise<void> => {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS itsm_attachments (
        id SERIAL PRIMARY KEY,
        ticket_type TEXT NOT NULL,
        ticket_id INTEGER NOT NULL,
        file_name TEXT NOT NULL,
        file_size INTEGER NOT NULL,
        content_type TEXT NOT NULL,
        object_path TEXT NOT NULL,
        uploaded_by INTEGER,
        uploaded_by_name TEXT,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);
    await pool.query(`CREATE INDEX IF NOT EXISTS idx_itsm_attachments_ticket ON itsm_attachments(ticket_type, ticket_id)`);
    res.json({ ok: true, message: "itsm_attachments table ensured." });
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: "Migration failed", detail: msg });
  }
});

export default router;
